import com.atlasvault.privatevault.Credential
import com.atlasvault.privatevault.VaultCrypto
import java.io.File

fun main(args: Array<String>) {
    require(args.size == 1)
    val passphrase = "AtlasDemoVaultOnly2026!".toCharArray()
    val session = VaultCrypto.create(passphrase)
    session.entries.add(Credential(title = "مثال وهمي", website = "https://example.com",
        username = "demo@example.com", password = "not-a-real-secret-123!",
        phone = "+212600000000", recoveryCodes = "FAKE-CODE-A\nFAKE-CODE-B",
        notes = "هذه بيانات اختبار فقط وليست حسابات حقيقية"))
    File(args[0]).writeBytes(VaultCrypto.seal(session))
    val verified = VaultCrypto.unlock(passphrase, File(args[0]).readBytes())
    check(verified.entries.size == 1 && verified.entries[0].title == "مثال وهمي")
    session.destroy(); verified.destroy(); passphrase.fill('\u0000')
    println("OK: demo backup generated and decrypted")
}
