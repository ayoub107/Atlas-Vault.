// Run locally: kotlinc app/src/main/java/com/atlasvault/privatevault/PasswordToolkit.kt PasswordToolkitSelfTest.kt -include-runtime -d /tmp/atlas-password-tests.jar && java -jar /tmp/atlas-password-tests.jar
import com.atlasvault.privatevault.PasswordToolkit

fun main() {
    // RFC 6238 time 59, SHA1 seed "12345678901234567890", expected 6-digit suffix.
    check(PasswordToolkit.totp("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", 59) == "287082")
    check(PasswordToolkit.totp("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", 1111111109) == "081804")
    repeat(1000) {
        val value = PasswordToolkit.generate(20, true, true, true, true)
        check(value.length == 20)
        check(value.any { it.isLowerCase() })
        check(value.any { it.isUpperCase() })
        check(value.any { it.isDigit() })
        check(value.any { !it.isLetterOrDigit() })
    }
    repeat(100) { check(PasswordToolkit.generate(12, true, false, false, false).length == 12) }
    println("OK: TOTP official SHA1 test vectors + 1,100 generated passwords")
}
