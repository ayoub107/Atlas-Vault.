// Run with kotlinc Credential.kt VaultCrypto.kt VaultCryptoSelfTest.kt -include-runtime -d /tmp/atlas-crypto.jar
import com.atlasvault.privatevault.Credential
import com.atlasvault.privatevault.VaultCrypto

fun main() {
    val secret = "Correct Horse Battery Staple 2026!".toCharArray()
    val candidate = VaultCrypto.create(secret)
    val example = Credential(
        title = "تجريبي فقط", website = "https://example.com", username = "example@example.com",
        password = "fake-password-123", phone = "+212600000000",
        recoveryEmail = "recovery@example.com", recoveryCodes = "CODE-A\nCODE-B",
        totpSecret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", notes = "تجربة استرجاع"
    )
    candidate.entries.add(example)
    val a = VaultCrypto.seal(candidate)
    val b = VaultCrypto.seal(candidate)
    check(!a.contentEquals(b)) // fresh random nonce and ciphertext on every save
    check(!String(a, Charsets.ISO_8859_1).contains("example@example.com"))
    VaultCrypto.verifyEnvelope(a)
    val restored = VaultCrypto.unlock(secret, a)
    check(restored.entries.single() == example)
    restored.destroy()
    check(restored.key.all { it == 0.toByte() })
    val edited = a.clone()
    edited[edited.lastIndex] = (edited.last().toInt() xor 1).toByte()
    check(runCatching { VaultCrypto.unlock(secret, edited) }.isFailure)
    check(runCatching { VaultCrypto.unlock("This is a different password".toCharArray(), a) }.isFailure)
    val corruptHeader = a.clone()
    corruptHeader[20] = (corruptHeader[20].toInt() xor 1).toByte()
    check(runCatching { VaultCrypto.unlock(secret, corruptHeader) }.isFailure)
    candidate.destroy()
    secret.fill('\u0000')
    println("OK: binary vault create/seal/unlock; authenticated header; tamper & wrong password fail; nonce rotates")
}
