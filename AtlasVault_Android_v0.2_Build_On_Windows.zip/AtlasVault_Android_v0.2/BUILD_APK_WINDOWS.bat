@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_APK_WINDOWS.ps1"
if errorlevel 1 (
    echo.
    echo BUILD FAILED. Read the error and INSTALL_AR.md.
    pause
    exit /b 1
)
echo.
echo BUILD FINISHED. Find AtlasVault-TEST.apk in this folder.
pause
