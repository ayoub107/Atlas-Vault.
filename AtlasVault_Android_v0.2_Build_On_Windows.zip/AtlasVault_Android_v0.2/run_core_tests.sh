#!/usr/bin/env bash
set -euo pipefail
SRC='app/src/main/java/com/atlasvault/privatevault'
kotlinc "$SRC/PasswordToolkit.kt" PasswordToolkitSelfTest.kt -include-runtime -d /tmp/atlas-password-tests.jar
java -jar /tmp/atlas-password-tests.jar
kotlinc "$SRC/Credential.kt" "$SRC/VaultCrypto.kt" VaultCryptoSelfTest.kt -include-runtime -d /tmp/atlas-crypto-tests.jar
java -jar /tmp/atlas-crypto-tests.jar
