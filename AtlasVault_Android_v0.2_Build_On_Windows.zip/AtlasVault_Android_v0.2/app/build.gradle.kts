plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.atlasvault.privatevault"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.atlasvault.privatevault"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0-test"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Use your own private release signing key for all future upgrades.
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
