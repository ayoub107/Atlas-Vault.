package com.atlasvault.privatevault

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

/**
 * Personal offline Android MVP. No internet, SMS, contacts or Accessibility permissions.
 * SAF export lets the owner select a compatible cloud DocumentsProvider or an independent drive.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(14, 20, 32)
    private val panel = Color.rgb(25, 35, 53)
    private val soft = Color.rgb(36, 50, 69)
    private val white = Color.rgb(244, 249, 255)
    private val muted = Color.rgb(163, 181, 203)
    private val accent = Color.rgb(94, 224, 185)
    private val danger = Color.rgb(255, 171, 142)

    private lateinit var store: VaultStore
    private lateinit var mainLayout: LinearLayout
    private var session: VaultCrypto.Session? = null
    private var pendingImport: ByteArray? = null
    private var pendingExport: String? = null
    private var inDocumentPicker = false
    private var lockPending = false
    private var operationInProgress = false
    private var currentPage = ""
    private val handler = Handler(Looper.getMainLooper())

    companion object {
        private const val REQUEST_EXPORT = 1001
        private const val REQUEST_IMPORT = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        store = VaultStore(this)
        mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            fitsSystemWindows = true
        }
        setContentView(mainLayout)
        if (store.exists()) showUnlock() else showSetup()
    }

    override fun onStop() {
        super.onStop()
        // Lock on leaving the app, except while the user is selecting an encrypted backup destination.
        if (!inDocumentPicker) {
            session?.destroy()
            session = null
            lockPending = true
            // Drop visible fields when the application moves to the background.
            mainLayout.removeAllViews()
        }
    }

    override fun onStart() {
        super.onStart()
        if (lockPending) {
            lockPending = false
            pendingImport = null
            if (store.exists()) showUnlock() else showSetup()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        session?.destroy()
        session = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (resources.displayMetrics.density * value + 0.5f).toInt()

    private fun shape(color: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(16).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun padding(view: View, horizontal: Int = 14, vertical: Int = 12) {
        view.setPadding(dp(horizontal), dp(vertical), dp(horizontal), dp(vertical))
    }

    private fun text(value: String, size: Float = 15f, bold: Boolean = false, color: Int = white): TextView =
        TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun column(parent: LinearLayout, background: Int? = null, spacing: Int = 10): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (background != null) this.background = shape(background)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = dp(spacing)
            parent.addView(this, params)
        }

    private fun gap(parent: LinearLayout, height: Int = 12) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun addText(parent: LinearLayout, value: String, size: Float = 15f, bold: Boolean = false, color: Int = white) {
        parent.addView(text(value, size, bold, color), LinearLayout.LayoutParams(-1, -2))
    }

    private fun card(parent: LinearLayout, content: (LinearLayout) -> Unit) {
        val c = column(parent, panel, 12)
        padding(c, 16, 16)
        content(c)
    }

    private fun button(label: String, primary: Boolean = true, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setTextColor(if (primary) bg else white)
            background = shape(if (primary) accent else soft)
            minHeight = dp(48)
            elevation = 0f
            setOnClickListener { action() }
        }

    private fun addButton(parent: LinearLayout, label: String, primary: Boolean = true, action: () -> Unit): Button =
        button(label, primary, action).also {
            val p = LinearLayout.LayoutParams(-1, dp(50))
            p.bottomMargin = dp(10)
            parent.addView(it, p)
        }

    private fun twoButtons(parent: LinearLayout, left: String, right: String, a: () -> Unit, b: () -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pa = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
        val pb = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
        row.addView(button(left, true, a), pa)
        row.addView(button(right, false, b), pb)
        parent.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    private fun edit(parent: LinearLayout, label: String, value: String = "", password: Boolean = false,
                     multiline: Boolean = false): EditText {
        addText(parent, label, 13f, true, muted)
        val field = EditText(this).apply {
            setText(value)
            hint = label
            setHintTextColor(muted)
            setTextColor(white)
            setTextSize(16f)
            background = shape(soft)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setSingleLine(!multiline)
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            }
            if (multiline) minLines = 3
            else minHeight = dp(46)
            padding(this, 12, 8)
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) }
        parent.addView(field, params)
        return field
    }

    private fun page(title: String, subtitle: String = "", back: (() -> Unit)? = null, build: (LinearLayout) -> Unit) {
        handler.removeCallbacksAndMessages(null)
        currentPage = title
        mainLayout.removeAllViews()
        val scroll = ScrollView(this).apply {
            fillViewport = true
            isVerticalScrollBarEnabled = false
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            padding(this, 18, 20)
        }
        scroll.addView(content)
        mainLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (back != null) addButton(content, "رجوع", false, back)
        addText(content, title, 27f, true)
        if (subtitle.isNotBlank()) {
            gap(content, 6)
            addText(content, subtitle, 14f, false, muted)
        }
        gap(content, 20)
        build(content)
        gap(content, 18)
    }

    private fun notify(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun <T> work(task: () -> T, success: (T) -> Unit) {
        if (operationInProgress) {
            notify("عملية أخرى قيد التنفيذ، أعد المحاولة بعد اكتمالها")
            return
        }
        operationInProgress = true
        Thread {
            try {
                val result = task()
                runOnUiThread {
                    operationInProgress = false
                    if (!isFinishing && !lockPending) success(result)
                    else if (result is VaultCrypto.Session) result.destroy()
                }
            } catch (error: Exception) {
                runOnUiThread {
                    operationInProgress = false
                    if (!isFinishing && !lockPending) AlertDialog.Builder(this)
                        .setTitle("تعذرت العملية")
                        .setMessage(error.message ?: "وقع خطأ غير متوقع")
                        .setPositiveButton("موافق", null)
                        .show()
                }
            }
        }.start()
    }

    private fun showSetup() = page(
        "أطلس فولت", "إنشاء خزنتك المشفرة لأول مرة. احتفظ بكلمة السر الرئيسية خارج الهاتف."
    ) { content ->
        card(content) {
            addText(it, "كلمة السر الرئيسية", 19f, true)
            gap(it)
            val pass = edit(it, "كلمة رئيسية لا تقل عن 12 حرفاً", password = true)
            val confirm = edit(it, "تأكيد كلمة السر", password = true)
            addText(it, "⚠️ إذا فقدت كلمة السر والنسخة المستقلة، لن يمكن استرجاع الخزنة.", 13f, false, danger)
            gap(it)
            addButton(it, "إنشاء الخزنة") {
                val pw = pass.text.toString().toCharArray()
                val match = confirm.text.toString().toCharArray()
                if (pw.size < 12 || !pw.contentEquals(match)) {
                    pw.fill('\u0000'); match.fill('\u0000')
                    notify("تحقق من كلمة السر والتأكيد، والحد الأدنى 12 حرفاً")
                    return@addButton
                }
                pass.text.clear(); confirm.text.clear()
                work({
                    try {
                        val candidate = VaultCrypto.create(pw)
                        try { store.write(VaultCrypto.seal(candidate)); candidate }
                        catch (error: Exception) { candidate.destroy(); throw error }
                    } finally { pw.fill('\u0000'); match.fill('\u0000') }
                }) { created ->
                    session = created
                    notify("تم إنشاء الخزنة. أنشئ نسختين احتياطيتين بعد إضافة حساباتك")
                    showHome()
                }
            }
        }
        addButton(content, "استرجاع خزنة من نسخة مشفرة", false) { pickImport() }
    }

    private fun showUnlock(fromImport: Boolean = false) = page(
        if (fromImport) "استرجاع النسخة" else "فتح الخزنة",
        if (fromImport) "أدخل كلمة السر الرئيسية للنسخة التي اخترتها. لن تتغير خزنتك الحالية قبل التأكد من صحتها."
        else "أدخل كلمة السر الرئيسية لفتح حساباتك المحلية."
    ) { content ->
        card(content) {
            val pass = edit(it, "كلمة السر الرئيسية", password = true)
            addButton(it, if (fromImport) "التحقق واسترجاع الخزنة" else "فتح الخزنة") {
                val password = pass.text.toString().toCharArray()
                pass.text.clear()
                val imported = if (fromImport) pendingImport else null
                if (fromImport && imported == null) { notify("اختار نسخة صالحة أولاً"); return@addButton }
                work({
                    try {
                        val bytes = imported ?: store.read()
                        val candidate = VaultCrypto.unlock(password, bytes)
                        if (imported != null) {
                            try { store.write(imported) } catch (error: Exception) { candidate.destroy(); throw error }
                        }
                        candidate
                    } finally { password.fill('\u0000') }
                }) { unlocked ->
                    session?.destroy()
                    session = unlocked
                    pendingImport = null
                    notify(if (imported != null) "تم استرجاع النسخة بنجاح" else "تم فتح الخزنة")
                    showHome()
                }
            }
        }
        addButton(content, "اختيار نسخة احتياطية مشفرة", false) { pickImport() }
        if (fromImport) addButton(content, "إلغاء الاسترجاع", false) {
            pendingImport = null
            if (session != null) showHome() else if (store.exists()) showUnlock() else showSetup()
        }
        card(content) {
            addText(it, "تنبيه أمني", 16f, true)
            gap(it, 8)
            addText(it, "ما كاينش زر سري لتجاوز كلمة السر. خاصك كلمة السر الرئيسية الأصلية أو نسخة عندك كلمة السر ديالها.", 13f, false, muted)
        }
    }

    private fun requireSession(): VaultCrypto.Session = session ?: error("الخزنة مقفلة")

    /**
     * Do not modify the live vault before its encrypted replacement reaches durable storage.
     * The candidate is sealed synchronously, so background locking cannot invalidate the key.
     */
    private fun persistEntries(updated: List<Credential>, finished: () -> Unit) {
        val vault = requireSession()
        val ciphertext = try {
            VaultCrypto.seal(VaultCrypto.Session(vault.key, vault.salt, updated.toMutableList()))
        } catch (error: Exception) {
            notify(error.message ?: "تعذر تشفير البيانات")
            return
        }
        work({ store.write(ciphertext) }) {
            val unlocked = session
            if (unlocked != null && unlocked === vault) {
                unlocked.entries.clear()
                unlocked.entries.addAll(updated)
                finished()
            }
        }
    }

    private fun showHome() {
        val s = session ?: run { showUnlock(); return }
        page("حساباتي", "خزنة مشفرة • ${s.entries.size} حساب محفوظ") { content ->
            addButton(content, "+ إضافة حساب جديد") { showEditor() }
            twoButtons(content, "توليد كلمة مرور", "النسخ والاسترجاع", { showGenerator() }, { showBackup() })
            gap(content, 8)
            val search = edit(content, "البحث عن منصة أو حساب")
            val list = column(content, null, 4)
            fun refresh(query: String) {
                list.removeAllViews()
                val rows = s.entries.filter { entry ->
                    entry.title.contains(query, true) || entry.website.contains(query, true) ||
                        entry.username.contains(query, true)
                }.sortedBy { it.title.lowercase() }
                if (rows.isEmpty()) addText(list, "ما كاين حتى حساب مطابق.", 14f, false, muted)
                rows.forEach { entry ->
                    card(list) { c ->
                        addText(c, entry.title.ifBlank { "حساب بدون اسم" }, 18f, true)
                        if (entry.username.isNotBlank()) {
                            gap(c, 3)
                            addText(c, entry.username, 13f, false, muted)
                        }
                        gap(c, 8)
                        addButton(c, "فتح تفاصيل الحساب", false) { showDetail(entry.id) }
                    }
                }
            }
            refresh("")
            search.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh(s?.toString() ?: "") }
                override fun afterTextChanged(s: Editable?) {}
            })
            gap(content, 10)
            addButton(content, "قفل الخزنة الآن", false) { lockNow() }
        }
    }

    private fun lockNow() {
        session?.destroy(); session = null
        if (store.exists()) showUnlock() else showSetup()
    }

    private fun showEditor(existing: Credential? = null) {
        val draft = existing ?: Credential()
        page(if (existing == null) "إضافة حساب" else "تعديل الحساب", "كل الحقول تُشفّر داخل الخزنة.", { showHome() }) { content ->
            card(content) { form ->
                val title = edit(form, "اسم المنصة", draft.title)
                val website = edit(form, "رابط الموقع (اختياري)", draft.website)
                val username = edit(form, "البريد أو اسم المستخدم", draft.username)
                val pass = edit(form, "كلمة السر", draft.password, password = true)
                addButton(form, "توليد كلمة سر قوية ووضعها هنا", false) {
                    generatorDialog { pass.setText(it) }
                }
                val phone = edit(form, "رقم الهاتف المرتبط بالمصادقة", draft.phone)
                val recoveryEmail = edit(form, "بريد استرجاع الحساب", draft.recoveryEmail)
                val recoveryCodes = edit(form, "رموز الاسترجاع (واحد في كل سطر)", draft.recoveryCodes, multiline = true)
                val totp = edit(form, "سر المصادقة Base32 (اختياري)", draft.totpSecret)
                val notes = edit(form, "ملاحظات واسترجاع الحساب", draft.notes, multiline = true)
                addText(form, "احتفظ برموز الاسترجاع في نسخة منفصلة آمنة أيضاً، ولا تضع رمز رسالة هاتف هنا على أنه مفتاح مصادقة.", 12f, false, muted)
                gap(form)
                addButton(form, "حفظ الحساب") {
                    if (title.text.isBlank()) { notify("اسم المنصة ضروري"); return@addButton }
                    val newItem = draft.copy(
                        title = title.text.toString().trim(),
                        website = website.text.toString().trim(),
                        username = username.text.toString().trim(),
                        password = pass.text.toString(),
                        phone = phone.text.toString().trim(),
                        recoveryEmail = recoveryEmail.text.toString().trim(),
                        recoveryCodes = recoveryCodes.text.toString(),
                        totpSecret = totp.text.toString().trim(),
                        notes = notes.text.toString(),
                        updatedAt = System.currentTimeMillis()
                    )
                    val entries = requireSession().entries.toMutableList()
                    val idx = entries.indexOfFirst { it.id == newItem.id }
                    if (idx >= 0) entries[idx] = newItem else entries.add(newItem)
                    persistEntries(entries) {
                        notify("تم حفظ الحساب مشفراً")
                        showHome()
                    }
                }
            }
        }
    }

    private fun showDetail(id: String) {
        val item = requireSession().entries.firstOrNull { it.id == id } ?: run { showHome(); return }
        page(item.title, item.website, { showHome() }) { content ->
            card(content) { c ->
                info(c, "المستخدم / البريد", item.username)
                info(c, "رقم هاتف المصادقة", item.phone)
                info(c, "بريد الاسترجاع", item.recoveryEmail)
                info(c, "ملاحظات", item.notes)
                info(c, "آخر تحديث", DateFormat.getDateTimeInstance().format(Date(item.updatedAt)))
            }
            card(content) { c ->
                addText(c, "كلمة السر", 16f, true)
                gap(c, 8)
                val display = text("••••••••••", 20f, true)
                c.addView(display)
                var visible = false
                twoButtons(c, "إظهار / إخفاء", "نسخ كلمة السر", {
                    visible = !visible
                    display.text = if (visible) item.password else "••••••••••"
                }, { copySecret("كلمة السر", item.password) })
            }
            if (item.totpSecret.isNotBlank()) {
                card(content) { c ->
                    addText(c, "رمز المصادقة الثنائية (كل 30 ثانية)", 16f, true)
                    gap(c, 6)
                    val code = text("------", 27f, true, accent)
                    c.addView(code)
                    val remaining = text("", 13f, false, muted)
                    c.addView(remaining)
                    val runnable = object : Runnable {
                        override fun run() {
                            if (currentPage != item.title) return
                            try {
                                code.text = PasswordToolkit.totp(item.totpSecret)
                                remaining.text = "متبقي ${30 - (System.currentTimeMillis() / 1000 % 30)} ثانية"
                            } catch (error: Exception) {
                                code.text = "مفتاح غير صالح"
                            }
                            handler.postDelayed(this, 1000)
                        }
                    }
                    handler.post(runnable)
                    gap(c, 5)
                    addButton(c, "نسخ الرمز الحالي", false) {
                        try { copySecret("رمز المصادقة", PasswordToolkit.totp(item.totpSecret)) }
                        catch (_: Exception) { notify("سر المصادقة غير صالح") }
                    }
                }
            }
            if (item.recoveryCodes.isNotBlank()) {
                card(content) { c ->
                    addText(c, "رموز الاسترجاع", 16f, true)
                    gap(c)
                    val codesText = text("مخفية", 15f)
                    c.addView(codesText)
                    var visible = false
                    twoButtons(c, "إظهار / إخفاء", "نسخ الرموز", {
                        visible = !visible
                        codesText.text = if (visible) item.recoveryCodes else "مخفية"
                    }, { copySecret("رموز الاسترجاع", item.recoveryCodes) })
                }
            }
            twoButtons(content, "تعديل", "حذف الحساب", { showEditor(item) }, {
                AlertDialog.Builder(this)
                    .setTitle("حذف الحساب نهائياً؟")
                    .setMessage("سيتم حذف هذا السجل من الخزنة المحلية. النسخ السابقة قد تظل تحتوي عليه.")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("حذف") { _, _ ->
                        val entries = requireSession().entries.filterNot { it.id == id }
                        persistEntries(entries) { showHome() }
                    }.show()
            })
        }
    }

    private fun info(parent: LinearLayout, label: String, value: String) {
        if (value.isBlank()) return
        addText(parent, label, 12f, true, muted)
        gap(parent, 5)
        addText(parent, value, 15f)
        gap(parent, 12)
    }

    private fun copySecret(label: String, value: String) {
        if (value.isEmpty()) { notify("لا توجد بيانات لنسخها"); return }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, value)
        if (Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
            }
        }
        clipboard.setPrimaryClip(clip)
        notify("تم النسخ. تجنب لصق البيانات في تطبيق غير موثوق")
    }

    private fun showGenerator() = page("مولّد كلمات المرور", "ولّد كلمة قوية عشوائياً ثم انسخها أو احفظها في حساب جديد.", { showHome() }) { content ->
        card(content) { c ->
            val length = text("الطول: 20 حرفاً", 18f, true)
            c.addView(length)
            val slider = SeekBar(this).apply { max = 52; progress = 8; progressTintList = ColorStateList.valueOf(accent) }
            c.addView(slider)
            val a = checkbox(c, "أحرف صغيرة", true)
            val b = checkbox(c, "أحرف كبيرة", true)
            val d = checkbox(c, "أرقام", true)
            val e = checkbox(c, "رموز", true)
            gap(c, 8)
            val result = text("", 20f, true, accent).apply {
                setTextIsSelectable(true)
                background = shape(soft)
                padding(this, 12, 14)
            }
            c.addView(result, LinearLayout.LayoutParams(-1, -2))
            fun regenerate() {
                try { result.text = PasswordToolkit.generate(slider.progress + 12, a.isChecked, b.isChecked, d.isChecked, e.isChecked) }
                catch (_: IllegalArgumentException) { notify("اختار نوع واحد من الحروف على الأقل") }
            }
            slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { length.text = "الطول: ${progress + 12} حرفاً" }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { regenerate() }
            })
            regenerate()
            gap(c, 14)
            addButton(c, "توليد كلمة جديدة") { regenerate() }
            twoButtons(c, "نسخ", "حفظ في حساب جديد", {
                copySecret("كلمة سر مولدة", result.text.toString())
            }, { showEditor(Credential(password = result.text.toString())) })
        }
        card(content) {
            addText(it, "كيف تختار كلمة قوية؟", 16f, true)
            gap(it, 8)
            addText(it, "استعمل كلمة مختلفة لكل منصة، واختار 16 إلى 24 حرفاً أو أكثر. المولّد يستعمل مصدراً آمناً للعشوائية.", 14f, false, muted)
        }
    }

    private fun checkbox(parent: LinearLayout, label: String, selected: Boolean): CheckBox = CheckBox(this).apply {
        text = label
        textSize = 15f
        setTextColor(white)
        isChecked = selected
        buttonTintList = ColorStateList.valueOf(accent)
        parent.addView(this)
    }

    private fun generatorDialog(selected: (String) -> Unit) {
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            padding(this, 20, 8)
        }
        val length = text("الطول: 20", 16f, true)
        body.addView(length)
        val seek = SeekBar(this).apply { max = 52; progress = 8 }
        body.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) { length.text = "الطول: ${progress + 12}" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val symbols = checkbox(body, "إضافة الرموز", true)
        AlertDialog.Builder(this)
            .setTitle("توليد كلمة قوية")
            .setView(body)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("استعمال الكلمة") { _, _ ->
                selected(PasswordToolkit.generate(seek.progress + 12, true, true, true, symbols.isChecked))
            }.show()
    }

    private fun showBackup() = page("النسخ والاسترجاع", "كل نسخة تنحفظ مشفرة قبل مغادرة التطبيق.", { showHome() }) { content ->
        card(content) {
            addText(it, "1. النسخة السحابية", 18f, true)
            gap(it, 8)
            addText(it, "في نافذة اختيار المكان، اختار مزود تخزين سحابي متوافق مع ملفات أندرويد، مثل حساب التخزين ديالك إذا بان في القائمة.", 14f, false, muted)
            gap(it)
            addButton(it, "تصدير نسخة مشفرة إلى التخزين السحابي") { pickExport("cloud") }
        }
        card(content) {
            addText(it, "2. النسخة المستقلة", 18f, true)
            gap(it, 8)
            addText(it, "صدر نسخة ثانية في مكان منفصل، مثل حاسوب أو وحدة تخزين. ما تعتمدش على جوج نسخ في نفس الهاتف.", 14f, false, muted)
            gap(it)
            addButton(it, "تصدير نسخة مستقلة", false) { pickExport("independent") }
        }
        card(content) {
            addText(it, "3. الاسترجاع", 18f, true)
            gap(it, 8)
            addText(it, "الاسترجاع كيطلب كلمة السر ديال النسخة. غادي يتحقق من صحة فك التشفير قبل تعويض الخزنة الحالية.", 14f, false, muted)
            gap(it)
            addButton(it, "اختيار نسخة لاسترجاعها", false) {
                AlertDialog.Builder(this)
                    .setTitle("قبل استرجاع نسخة أخرى")
                    .setMessage("الاسترجاع الناجح سيعوض الخزنة الحالية. صدّر النسخة الحالية أولاً إذا كانت فيها معلومات مهمة.")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("متابعة") { _, _ -> pickImport() }
                    .show()
            }
        }
        addText(content, "ملاحظة: التصدير يتم يدوياً في هذه النسخة. لا يوجد تزامن تلقائي ولا تحقق آلي من اكتمال رفع الملف إلى السحابة.", 13f, false, danger)
    }

    private fun pickExport(type: String) {
        if (!store.exists()) { notify("أنشئ الخزنة أولاً"); return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "atlas-vault-${System.currentTimeMillis()}-$type.avault")
        }
        pendingExport = type
        inDocumentPicker = true
        try { startActivityForResult(intent, REQUEST_EXPORT) }
        catch (error: Exception) { inDocumentPicker = false; notify("لم يتم فتح اختيار مكان الحفظ") }
    }

    private fun pickImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        inDocumentPicker = true
        try { startActivityForResult(intent, REQUEST_IMPORT) }
        catch (error: Exception) { inDocumentPicker = false; notify("لم يتم فتح اختيار الملفات") }
    }

    @Deprecated("Android API callback, used to avoid external dependencies in this prototype")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        inDocumentPicker = false
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) { pendingExport = null; return }
        when (requestCode) {
            REQUEST_EXPORT -> {
                val type = pendingExport
                pendingExport = null
                work({
                    val bytes = store.read()
                    contentResolver.openOutputStream(uri, "w")?.use { out ->
                        out.write(bytes)
                        out.flush()
                    } ?: throw IllegalStateException("تعذر الكتابة في الملف")
                    bytes.size
                }) { size ->
                    notify("تم تصدير ملف مشفر ($size بايت). تأكد أنه محفوظ في المكان الصحيح")
                    if (type == "cloud") notify("صدر نسخة ثانية مستقلة أيضاً")
                }
            }
            REQUEST_IMPORT -> {
                work({
                    val bytes = contentResolver.openInputStream(uri)?.use { VaultStore.limitedRead(it) }
                        ?: throw IllegalStateException("تعذر فتح الملف")
                    VaultCrypto.verifyEnvelope(bytes)
                    bytes
                }) { bytes ->
                    pendingImport = bytes
                    showUnlock(fromImport = true)
                }
            }
        }
    }

    @Deprecated("Legacy back navigation for API 26 compatibility")
    override fun onBackPressed() {
        when {
            pendingImport != null -> { pendingImport = null; if (session != null) showHome() else showUnlock() }
            session != null && currentPage != "حساباتي" -> showHome()
            session != null -> lockNow()
            else -> super.onBackPressed()
        }
    }
}
