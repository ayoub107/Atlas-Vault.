package com.atlasvault.privatevault

import java.util.UUID

/** A decrypted record; all fields are encrypted together when serialized by VaultCrypto. */
data class Credential(
    val id: String = UUID.randomUUID().toString(),
    var title: String = "",
    var website: String = "",
    var username: String = "",
    var password: String = "",
    var phone: String = "",
    var recoveryEmail: String = "",
    var recoveryCodes: String = "",
    var totpSecret: String = "",
    var notes: String = "",
    var updatedAt: Long = System.currentTimeMillis()
)
