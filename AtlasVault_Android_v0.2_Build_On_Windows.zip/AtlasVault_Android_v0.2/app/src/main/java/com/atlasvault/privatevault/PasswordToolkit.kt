package com.atlasvault.privatevault

import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Uses SecureRandom; at least one character of every selected category is guaranteed. */
object PasswordToolkit {
    private val random = SecureRandom()
    private const val LOWER = "abcdefghijkmnopqrstuvwxyz" // exclude ambiguous 'l'
    private const val UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ" // exclude I and O
    private const val DIGITS = "23456789" // exclude 0 and 1
    private const val SYMBOLS = "!@#\$%&*+-=?_"

    fun generate(length: Int, lower: Boolean, upper: Boolean, numbers: Boolean, symbols: Boolean): String {
        require(length in 12..64)
        val groups = listOfNotNull(
            LOWER.takeIf { lower }, UPPER.takeIf { upper },
            DIGITS.takeIf { numbers }, SYMBOLS.takeIf { symbols }
        )
        require(groups.isNotEmpty())
        val all = groups.joinToString("")
        val chars = MutableList(length) { all[random.nextInt(all.length)] }
        for (index in groups.indices) {
            val group = groups[index]
            chars[index] = group[random.nextInt(group.length)]
        }
        for (i in chars.lastIndex downTo 1) {
            val j = random.nextInt(i + 1)
            val t = chars[i]
            chars[i] = chars[j]
            chars[j] = t
        }
        return chars.joinToString("")
    }

    /** RFC 6238 TOTP (SHA-1 / 6 digits / 30 seconds), input is a base32 secret. */
    fun totp(base32: String, epochSeconds: Long = System.currentTimeMillis() / 1000): String {
        val key = decodeBase32(base32)
        require(key.isNotEmpty()) { "رمز المصادقة غير صالح" }
        val counter = epochSeconds / 30L
        val msg = ByteArray(8) { i -> (counter ushr (8 * (7 - i))).toByte() }
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(key, "HmacSHA1"))
        val hash = mac.doFinal(msg)
        key.fill(0)
        val offset = hash.last().toInt() and 0x0f
        val binary = ((hash[offset].toInt() and 0x7f) shl 24) or
            ((hash[offset + 1].toInt() and 0xff) shl 16) or
            ((hash[offset + 2].toInt() and 0xff) shl 8) or
            (hash[offset + 3].toInt() and 0xff)
        return (binary % 1_000_000).toString().padStart(6, '0')
    }

    private fun decodeBase32(value: String): ByteArray {
        val input = value.uppercase().filterNot { it == ' ' || it == '-' || it == '=' || it == '\n' }
        require(input.isNotEmpty())
        var bits = 0
        var accumulator = 0
        val out = ArrayList<Byte>()
        for (ch in input) {
            val digit = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".indexOf(ch)
            require(digit >= 0) { "سر المصادقة يجب أن يكون بصيغة Base32" }
            accumulator = (accumulator shl 5) or digit
            bits += 5
            if (bits >= 8) {
                bits -= 8
                out.add(((accumulator ushr bits) and 255).toByte())
            }
        }
        return out.toByteArray()
    }
}
