package com.atlasvault.privatevault

import android.content.Context
import android.util.AtomicFile
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.File

/** Prevents partial overwrite of the local encrypted vault. */
class VaultStore(context: Context) {
    private val vault = AtomicFile(File(context.filesDir, "vault.avault"))

    fun exists(): Boolean = vault.baseFile.exists()
    fun read(): ByteArray = vault.openRead().use { it.readBytes() }

    fun write(bytes: ByteArray) {
        VaultCrypto.verifyEnvelope(bytes)
        val stream = vault.startWrite()
        try {
            stream.write(bytes)
            vault.finishWrite(stream)
        } catch (error: Exception) {
            vault.failWrite(stream)
            throw error
        }
    }

    companion object {
        fun limitedRead(stream: InputStream, maxBytes: Int = 10 * 1024 * 1024): ByteArray {
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            while (true) {
                val count = stream.read(buffer)
                if (count == -1) break
                require(out.size() + count <= maxBytes) { "الملف كبير جداً" }
                out.write(buffer, 0, count)
            }
            return out.toByteArray()
        }
    }
}
