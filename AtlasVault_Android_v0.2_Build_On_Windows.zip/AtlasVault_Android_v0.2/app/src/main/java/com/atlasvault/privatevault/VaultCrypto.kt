package com.atlasvault.privatevault

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Binary vault v1: magic[4], version[1], kdf_iterations[4], salt[16], nonce[12],
 * ciphertext_length[4], encrypted UTF-8 fields. All header bytes are authenticated as AAD.
 * No Android or third-party dependencies, so its exact encryption/decryption paths can be
 * exercised by standard JVM tests before incorporating in an Android application.
 */
object VaultCrypto {
    private val random = SecureRandom()
    private val MAGIC = byteArrayOf(0x41, 0x56, 0x4C, 0x54) // "AVLT"
    private const val ITERATIONS = 600_000
    private const val VERSION = 1
    private const val MAX_BYTES = 10 * 1024 * 1024
    private const val HEADER_BYTES = 4 + 1 + 4 + 16 + 12 + 4
    private const val MAX_FIELD_BYTES = 2 * 1024 * 1024

    data class Session(
        val key: ByteArray,
        val salt: ByteArray,
        val entries: MutableList<Credential>
    ) {
        fun destroy() {
            key.fill(0)
            salt.fill(0)
            entries.clear()
        }
    }

    fun create(masterPassword: CharArray): Session {
        require(masterPassword.size >= 12) { "كلمة السر الرئيسية خاصها 12 حرف على الأقل" }
        val salt = ByteArray(16).also { random.nextBytes(it) }
        return Session(deriveKey(masterPassword, salt), salt, mutableListOf())
    }

    private fun deriveKey(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally { spec.clearPassword() }
    }

    private fun writeField(out: DataOutputStream, value: String) {
        val utf8 = value.toByteArray(StandardCharsets.UTF_8)
        require(utf8.size <= MAX_FIELD_BYTES) { "حقل أكبر من الحد المسموح" }
        out.writeInt(utf8.size)
        out.write(utf8)
        utf8.fill(0)
    }

    private fun readField(input: DataInputStream): String {
        val count = input.readInt()
        require(count >= 0 && count <= MAX_FIELD_BYTES && count <= input.available()) { "حجم الحقل غير صالح" }
        val bytes = ByteArray(count)
        input.readFully(bytes)
        return try { String(bytes, StandardCharsets.UTF_8) }
        finally { bytes.fill(0) }
    }

    private fun encodePayload(entries: List<Credential>): ByteArray {
        require(entries.size <= 50_000)
        val data = ByteArrayOutputStream()
        DataOutputStream(data).use { out ->
            out.writeInt(entries.size)
            for (e in entries) {
                writeField(out, e.id)
                writeField(out, e.title)
                writeField(out, e.website)
                writeField(out, e.username)
                writeField(out, e.password)
                writeField(out, e.phone)
                writeField(out, e.recoveryEmail)
                writeField(out, e.recoveryCodes)
                writeField(out, e.totpSecret)
                writeField(out, e.notes)
                out.writeLong(e.updatedAt)
            }
        }
        return data.toByteArray()
    }

    private fun decodePayload(bytes: ByteArray): MutableList<Credential> {
        val input = DataInputStream(ByteArrayInputStream(bytes))
        val count = input.readInt()
        require(count in 0..50_000) { "عدد السجلات غير صالح" }
        val entries = mutableListOf<Credential>()
        repeat(count) {
            entries.add(Credential(
                id = readField(input),
                title = readField(input),
                website = readField(input),
                username = readField(input),
                password = readField(input),
                phone = readField(input),
                recoveryEmail = readField(input),
                recoveryCodes = readField(input),
                totpSecret = readField(input),
                notes = readField(input),
                updatedAt = input.readLong()
            ))
        }
        require(input.available() == 0) { "بيانات إضافية غير متوقعة" }
        return entries
    }

    private fun header(salt: ByteArray, nonce: ByteArray, ciphertextLength: Int): ByteArray {
        val output = ByteArrayOutputStream(HEADER_BYTES)
        DataOutputStream(output).use { out ->
            out.write(MAGIC)
            out.writeByte(VERSION)
            out.writeInt(ITERATIONS)
            out.write(salt)
            out.write(nonce)
            out.writeInt(ciphertextLength)
        }
        return output.toByteArray()
    }

    fun verifyEnvelope(bytes: ByteArray) {
        require(bytes.size in (HEADER_BYTES + 16)..MAX_BYTES) { "حجم النسخة الاحتياطية غير صالح" }
        val input = DataInputStream(ByteArrayInputStream(bytes))
        val magic = ByteArray(4).also { input.readFully(it) }
        require(magic.contentEquals(MAGIC)) { "الملف ليس نسخة أطلس فولت" }
        require(input.readUnsignedByte() == VERSION) { "إصدار الخزنة غير مدعوم" }
        require(input.readInt() == ITERATIONS) { "إعدادات حماية غير مدعومة" }
        val ignoredSalt = ByteArray(16)
        val ignoredNonce = ByteArray(12)
        input.readFully(ignoredSalt)
        input.readFully(ignoredNonce)
        val cipherSize = input.readInt()
        require(cipherSize >= 16 && cipherSize.toLong() + HEADER_BYTES == bytes.size.toLong()) { "طول الملف غير صحيح" }
    }

    fun seal(session: Session): ByteArray {
        require(session.key.size == 32 && session.salt.size == 16)
        val plaintext = encodePayload(session.entries)
        try {
            require(plaintext.size + HEADER_BYTES + 16 <= MAX_BYTES) { "الخزنة أكبر من الحجم المسموح" }
            val nonce = ByteArray(12).also { random.nextBytes(it) }
            val authenticatedHeader = header(session.salt, nonce, plaintext.size + 16)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(session.key, "AES"), GCMParameterSpec(128, nonce))
            cipher.updateAAD(authenticatedHeader)
            val ciphertext = cipher.doFinal(plaintext)
            return authenticatedHeader + ciphertext
        } finally { plaintext.fill(0) }
    }

    fun unlock(masterPassword: CharArray, bytes: ByteArray): Session {
        verifyEnvelope(bytes)
        val input = DataInputStream(ByteArrayInputStream(bytes))
        input.skipBytes(4 + 1 + 4)
        val salt = ByteArray(16).also { input.readFully(it) }
        val nonce = ByteArray(12).also { input.readFully(it) }
        val cipherSize = input.readInt()
        val ciphertext = ByteArray(cipherSize).also { input.readFully(it) }
        val key = deriveKey(masterPassword, salt)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            cipher.updateAAD(bytes, 0, HEADER_BYTES)
            val plaintext = cipher.doFinal(ciphertext)
            try {
                val entries = decodePayload(plaintext)
                return Session(key, salt, entries)
            } finally { plaintext.fill(0) }
        } catch (ex: Exception) {
            key.fill(0)
            if (ex is AEADBadTagException) throw IllegalArgumentException("كلمة السر غير صحيحة أو النسخة تالفة")
            throw ex
        } finally { ciphertext.fill(0) }
    }
}
