# ATLAS VAULT: Windows build helper. The output is for TESTING only.
# Downloads the OFFICIAL Gradle 8.11.1 distribution, checks its SHA-256,
# and builds with the Android SDK already installed by Android Studio.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$version = '8.11.1'
$toolRoot = Join-Path $root '.local-build-tools'
$gradleHome = Join-Path $toolRoot "gradle-$version"
$gradleBat = Join-Path $gradleHome 'bin\gradle.bat'

Write-Host ''
Write-Host 'ATLAS VAULT: Android test APK builder'
Write-Host 'This is a TEST build; do not store real passwords yet.'
Write-Host ''

$sdkCandidates = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, (Join-Path $env:LOCALAPPDATA 'Android\Sdk'))
$sdk = $null
foreach ($candidate in $sdkCandidates) {
    if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path (Join-Path $candidate 'platforms\android-35\android.jar'))) {
        $sdk = $candidate
        break
    }
}
if (-not $sdk) {
    throw 'Android SDK 35 not found. Open Android Studio > SDK Manager and install Android SDK Platform 35, Android SDK Build-Tools 35, and Android SDK Platform-Tools. Then run this again.'
}
$env:ANDROID_HOME = $sdk
$env:ANDROID_SDK_ROOT = $sdk
Write-Host "Android SDK found: $sdk"

$studioJdk = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
if (Test-Path (Join-Path $studioJdk 'bin\java.exe')) {
    $env:JAVA_HOME = $studioJdk
    $env:PATH = (Join-Path $studioJdk 'bin') + ';' + $env:PATH
}
if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    throw 'Java not found. Install Android Studio (includes JDK 17+) and run again.'
}
Write-Host 'Java:'
& java -version
if ($LASTEXITCODE -ne 0) { throw 'Java did not start successfully.' }

if (-not (Test-Path $gradleBat)) {
    New-Item -ItemType Directory -Path $toolRoot -Force | Out-Null
    $baseUrl = "https://services.gradle.org/distributions/gradle-$version-bin.zip"
    $zipFile = Join-Path $toolRoot "gradle-$version-bin.zip"
    $shaFile = "$zipFile.sha256"
    Write-Host 'Downloading the official Gradle distribution (about 131 MB)...'
    Invoke-WebRequest -UseBasicParsing -Uri $baseUrl -OutFile $zipFile
    Invoke-WebRequest -UseBasicParsing -Uri "$baseUrl.sha256" -OutFile $shaFile
    $expected = ((Get-Content $shaFile -Raw).Trim() -split '\s+')[0].ToLowerInvariant()
    $actual = (Get-FileHash -Algorithm SHA256 $zipFile).Hash.ToLowerInvariant()
    if ($expected -notmatch '^[0-9a-f]{64}$' -or $expected -ne $actual) {
        Remove-Item -Force $zipFile -ErrorAction SilentlyContinue
        throw 'Gradle archive SHA-256 verification failed. Aborting.'
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipFile, $toolRoot)
    if (-not (Test-Path $gradleBat)) { throw 'Gradle was not extracted as expected.' }
    Remove-Item -Force $zipFile, $shaFile -ErrorAction SilentlyContinue
}

Push-Location $root
try {
    Write-Host ''
    Write-Host 'Building Android TEST APK...'
    & $gradleBat --no-daemon :app:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle failed (exit $LASTEXITCODE)." }
    $output = Join-Path $root 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path $output)) { throw 'Build completed but APK was not found.' }
    $copy = Join-Path $root 'AtlasVault-TEST.apk'
    Copy-Item $output $copy -Force
    Write-Host ''
    Write-Host 'SUCCESS! Test APK file:'
    Write-Host $copy
    Write-Host 'Copy it to your Android phone to install. Read INSTALL_AR.md first.'
} finally {
    Pop-Location
}
