# DEMO BACKUP ONLY — NO REAL ACCOUNTS

Encrypted example: `TEST_ONLY_BACKUP.avault`.

**Test master password:** `AtlasDemoVaultOnly2026!`

This backup contains **invented credentials** for example.com. Use it only to test the first-install/import/decrypt flow. Do not use this publicly known master password for your real accounts. Before attempting any actual uninstall/recovery test, export two new encrypted backups and verify them independently.
