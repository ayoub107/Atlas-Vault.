# Security notes (v0.2 test prototype)

**NOT AUDITED. DO NOT TRUST WITH REAL CREDENTIALS UNTIL VALIDATED.**

- AES-256-GCM encrypted whole-vault records, random 96-bit nonce per write, AAD binds format/version.
- PBKDF2-HMAC-SHA256 600,000 iterations and 16-byte random salt. A passphrase-based vault cannot prevent sufficiently powerful offline guessing if the passphrase is weak. Argon2id may be preferable in audited later releases.
- Vault data resides in app-private storage as a single authenticated ciphertext envelope; writes are atomic.
- JSON structures, Kotlin Strings, activity inputs and in-memory credentials are not comprehensively zeroized. Android process RAM and clipboard may retain secrets after a screen closes. Minimize exposure; improve in security review.
- Local Android OS auto-backup disabled, external encrypted export through user-driven SAF only. SAF providers may not support all cloud destinations; successful writing does not prove remote replication. User must verify.
- Locks on background apart from the system document-picker flow; no biometric authentication in this release.
- No INTERNET, READ_SMS, accessibility, contacts, or background automation permissions.
- TOTP secret and recovery codes reside in *the same vault* as passwords, so compromise of vault compromises both factors. For high-risk accounts, use an independent authenticator/security key.
- No auto-fill service; never automatically send credentials to other apps without exact origin/package verification and explicit user consent.
- Password clipboard marked sensitive on API33+, but contents are not guaranteed to be inaccessible to all apps or keyboards; no automatic clipboard clearing.
- Recovery requires encrypted backup file and original master passphrase. No recovery backdoor.
- This is a source-code MVP, not an APK, not a tested security product.

## Reference guidance

- https://mas.owasp.org/MASTG/0x04g-Testing-Cryptography/
- https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- https://developer.android.com/guide/topics/providers/document-provider
- https://developer.android.com/identity/autofill

- Local session updates are now committed only after a successful atomic encrypted write, avoiding unsaved changes in the live in-memory vault when storage fails.
